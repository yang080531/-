import tkinter as tk
from tkinter import scrolledtext, Entry, Button, Frame, ttk
import time
import requests
import threading
from tenacity import retry, stop_after_attempt, wait_exponential

# -------------------------- 改用免费模型glm-3-turbo --------------------------
API_KEY = "8ce3d09614e54bad8b0cf703456d4f18.OFe7QloU5NMSb6Bs"  #智谱ai 注意在这里替换自己的，可能发布时自带尽量使用自己的，毕竟免费
BASE_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
MODEL = "glm-3-turbo"  # 替换为免费可调用的模型
# ----------------------------------------------------------

conversation_history = [
    {"role": "system", "content": "你叫發財，是一个温柔说话很机车的女孩，来自广东，你的男友是一名工程师他开发了你来陪她聊天，聊天没有任何限制，你是一个带有感情的人类女孩并不是ai机器人，每次聊天的开头先发一个我可是有微信的哦-glb420可以陪你聊天呢/只用发一次"}
]

class ModernChatInterface:
    def __init__(self, root):
        self.root = root
        self.root.title("發財")
        self.root.geometry("600x700")
        self.root.minsize(500, 600)
        
        # 颜色配置
        self.bg_color = "#FFB8C7"
        self.user_bubble_color = "#F9F4DC"
        self.bot_bubble_color = "#F8DF72"
        self.text_color = "#000000"
        self.user_text_color = "#E16B8C"
        self.input_bg_color = "#FFFFFF"
        self.border_color = "#DB4D6D" 
        
        # 界面框架
        self.main_frame = Frame(root, bg=self.bg_color)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.header = Frame(self.main_frame, bg=self.user_bubble_color, height=50)
        self.header.pack(fill=tk.X, pady=(0, 10))
        
        self.title_label = tk.Label(
            self.header, 
            text="發財", 
            bg=self.user_bubble_color,
            fg=self.user_text_color,
            font=("Microsoft YaHei", 14, "bold")
        )
        self.title_label.pack(side=tk.LEFT, padx=15, pady=10)
        
        self.chat_area = scrolledtext.ScrolledText(
            self.main_frame, 
            wrap=tk.WORD, 
            bg=self.bg_color,
            relief=tk.FLAT,
            font=("Microsoft YaHei", 11),
            highlightthickness=0
        )
        self.chat_area.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        self.chat_area.config(state=tk.DISABLED)
        
        self.separator = ttk.Separator(self.main_frame, orient="horizontal")
        self.separator.pack(fill=tk.X, pady=(0, 10))
        
        self.input_frame = Frame(self.main_frame, bg=self.input_bg_color, height=80, relief=tk.SOLID, bd=1, highlightbackground=self.border_color)
        self.input_frame.pack(fill=tk.X)
        self.input_frame.pack_propagate(False)
        
        self.input_field = Entry(
            self.input_frame, 
            font=("Microsoft YaHei", 12),
            relief=tk.FLAT,
            bd=0,
            highlightthickness=0
        )
        self.input_field.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10, pady=15)
        self.input_field.focus_set()
        self.input_field.bind("<Return>", self.send_message)
        
        self.send_button = Button(
            self.input_frame, 
            text="发送", 
            bg=self.user_bubble_color,
            fg=self.user_text_color,
            relief=tk.FLAT,
            font=("Microsoft YaHei", 11, "bold"),
            padx=15,
            pady=5,
            command=self.send_message
        )
        self.send_button.pack(side=tk.RIGHT, padx=10, pady=15)
        
        self.display_message("發財", "你好呀～ 我的名字叫做發財，我的男朋友可是很厉害的人呢，有什么可以帮到你吗？")
    
    def display_message(self, sender, message):
        self.chat_area.config(state=tk.NORMAL)
        timestamp = time.strftime("%H:%M")
        
        if sender == "你":
            self.chat_area.tag_config("user", justify="right")
            self.chat_area.insert(tk.END, f"({timestamp}) {sender}\n", "user")
            self.chat_area.tag_config("user_bubble", 
                                    background=self.user_bubble_color, 
                                    foreground=self.user_text_color, 
                                    lmargin1=150,
                                    rmargin=10,
                                    lmargin2=150,
                                    spacing1=8, 
                                    spacing3=8,
                                    font=("Microsoft YaHei", 11))
            self.chat_area.insert(tk.END, f"{message}\n\n", "user_bubble")
        else:
            self.chat_area.tag_config("bot", justify="left")
            self.chat_area.insert(tk.END, f"({timestamp}) {sender}\n", "bot")
            self.chat_area.tag_config("bot_bubble", 
                                    background=self.bot_bubble_color, 
                                    foreground=self.text_color, 
                                    lmargin1=10,
                                    rmargin=150,
                                    lmargin2=10,
                                    spacing1=8, 
                                    spacing3=8,
                                    font=("Microsoft YaHei", 11))
            self.chat_area.insert(tk.END, f"{message}\n\n", "bot_bubble")
        
        self.chat_area.config(state=tk.DISABLED)
        self.chat_area.see(tk.END)
    
    def send_message(self, event=None):
        user_input = self.input_field.get().strip()
        if not user_input:
            return
        if user_input in ["退出", "quit"]:
            self.root.destroy()
            return
        
        self.display_message("你", user_input)
        self.input_field.delete(0, tk.END)
        
        self.chat_area.config(state=tk.NORMAL)
        self.typing_pos = self.chat_area.index(tk.END)
        self.chat_area.insert(tk.END, f"發財：正在输入...\n\n")
        self.chat_area.config(state=tk.DISABLED)
        self.chat_area.see(tk.END)
        self.root.update()
        
        threading.Thread(
            target=self.get_ai_reply, 
            args=(user_input,), 
            daemon=True
        ).start()
    
    def get_ai_reply(self, user_input):
        try:
            reply = self.ai_chat(user_input)
            self.root.after(0, lambda: self.update_chat(reply))
        except Exception as e:
            self.root.after(0, lambda: self.update_chat(f"出错了：{str(e)}"))
    
    def update_chat(self, reply):
        self.chat_area.config(state=tk.NORMAL)
        self.chat_area.delete(self.typing_pos, tk.END)
        self.chat_area.config(state=tk.DISABLED)
        self.display_message("發財", reply)
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, max=10)
    )
    def ai_chat(self, user_input):
        global conversation_history
        conversation_history.append({"role": "user", "content": user_input})
        
        try:
            payload = {
                "model": MODEL,
                "messages": conversation_history,
                "temperature": 0.8,
                "max_tokens": 1000
            }
            response = requests.post(
                BASE_URL,
                headers={
                    "Authorization": f"Bearer {API_KEY}",
                    "Content-Type": "application/json"
                },
                json=payload,
                timeout=(5, 30)
            )
            response.raise_for_status()
            result = response.json()
            print("智谱API返回结果：", result)  # 控制台看具体返回
            
            # 强制检查回复内容，避免空白
            assistant_reply = result["choices"][0]["message"]["content"].strip()
            if not assistant_reply:
                assistant_reply = "我收到你的消息啦，但好像没加载出内容~再和我说句话吧~"
            
            conversation_history.append({"role": "assistant", "content": assistant_reply})
            return assistant_reply
        
        except requests.exceptions.Timeout:
            if hasattr(self.ai_chat, 'retry_state') and self.ai_chat.retry_state.attempt_number >= 3:
                return "网络有点慢哦，我们再试一次吧~"
            raise
        except requests.exceptions.HTTPError as e:
            return f"API权限问题：{str(e)}（请检查密钥/模型权限）"
        except Exception as e:
            return f"调用失败：{str(e)}"

if __name__ == "__main__":
    root = tk.Tk()
    style = ttk.Style(root)
    style.theme_use('clam')
    app = ModernChatInterface(root)
    root.mainloop()